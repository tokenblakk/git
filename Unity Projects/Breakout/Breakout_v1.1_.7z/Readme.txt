Tramel Jones 2012
A short game made in Unity

Mouse moves paddle left and right
Try to break all the blocks!